Approved images for My English Journey. Upload this ZIP unchanged to assets/ or assets/import/ in rouhous/English-Foundation. The GitHub Actions workflow installs four new images and learning routes.
