MEJ 5 new owner-approved images

Contains 5 approved WebP images and manifest.csv for insertion into GitHub.
Words: go hiking, go camping, go sailing, go snorkelling, photography.
